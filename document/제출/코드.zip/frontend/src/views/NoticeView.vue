<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "NoticeView",
  components: {},
  data() {
    return {};
  },
  created() {},
  methods: {},
};
</script>

<style scoped></style>
