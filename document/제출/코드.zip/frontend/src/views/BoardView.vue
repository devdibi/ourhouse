<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "BoardView",
  components: {},
  data() {
    return {};
  },
  created() {},
  methods: {},
};
</script>

<style scoped></style>
