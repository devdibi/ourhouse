package com.ssafy.ourhouse.dto;

public class BusStopDto {

}
