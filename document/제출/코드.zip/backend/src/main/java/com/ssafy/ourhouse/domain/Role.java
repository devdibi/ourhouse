package com.ssafy.ourhouse.domain;

public enum Role {

    USER,
    ADMIN
}
