package com.ssafy.ourhouse.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MedicalDto {
	
	private String name;

	private double lng;

	private double lat;
}
